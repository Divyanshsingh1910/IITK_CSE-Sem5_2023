#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>

static long g_ctr[4];

void* do_inc(void *arg)
{
     int ctr, tnum = *(int *)arg;
     char *ptr = malloc(32);
     for(ctr=0; ctr<100; ++ctr){
           g_ctr[tnum] += 10 + tnum;
     }
     sprintf(ptr, "Thread-%d", tnum);
     return ptr;
}

int main()
{
  int num_threads = 4, ctr;
  pthread_t threads[4];
  int tids[4];
  void *retval;

  /*Create threads*/      
  for(ctr=0; ctr < num_threads; ++ctr){
        tids[ctr] = ctr;
        if(pthread_create(&threads[ctr], NULL, do_inc, &tids[ctr]) != 0){
              perror("pthread_create");
              exit(-1);
        }
  }
  /*Wait for threads to finish their execution*/      
  for(ctr=0; ctr < num_threads; ++ctr){
        pthread_join(threads[ctr], &retval);
        printf("Joined %s with value %ld\n", (char *) retval, g_ctr[ctr]);
        free(retval);
  }
}
