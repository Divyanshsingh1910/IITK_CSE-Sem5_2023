#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>

void* thfunc(void *arg)
{
     int ctr = 0;
     printf("Thread stack pointer = %p\n", &ctr);
     return NULL;
}

int main()
{
  pthread_t tid;
  if(pthread_create(&tid, NULL, thfunc, NULL) != 0){
              perror("pthread_create");
              exit(-1);
  }
  printf("Main stack pointer = %p\n", &tid);
  pthread_join(tid, NULL);
}
