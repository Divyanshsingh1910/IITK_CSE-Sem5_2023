#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>

#define MAX_THREADS 64
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);


#define OP_COUNT 10000000UL
static long g_ctr;

void* do_inc(void *arg)
{
     unsigned long ctr;
     for(ctr=0; ctr<OP_COUNT; ++ctr){
         // g_ctr++;
          asm volatile("lock incq %0;"
                        :"=m" (g_ctr)
                        :
                        :"memory");
     }
     return NULL;
}

int main(int argc, char **argv)
{
  int num_threads, ctr;
  pthread_t *threads;
  if(argc !=2)
           USAGE_EXIT("not enough parameters");

  
  num_threads = atoi(argv[1]);
  if(num_threads <=0 || num_threads > MAX_THREADS){
          USAGE_EXIT("invalid num of threads");
  }

  threads = malloc(num_threads * sizeof(pthread_t));
  /*Create threads*/      
  for(ctr=0; ctr < num_threads; ++ctr){
        if(pthread_create(threads+ctr, NULL, do_inc, NULL) != 0){
              perror("pthread_create");
              exit(-1);
        }
 
  }
  
  /*Wait for threads to finish their execution*/      
  for(ctr=0; ctr < num_threads; ++ctr){
        pthread_join(threads[ctr], NULL);
  }
     
  printf("Final value = %ld\n", g_ctr);
  free(threads);
}
